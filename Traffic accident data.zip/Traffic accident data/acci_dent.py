import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load dataset
df = pd.read_csv("C:\\Users\\Fetcy Exshelya\\OneDrive\\Desktop\\skillcraft task relevant folders\\Traffic accident data\\accident.csv")  # Change path if needed

# Set seaborn style
sns.set(style="whitegrid")

# Drop missing values for critical analysis columns
df_clean = df.dropna(subset=["Speed_of_Impact", "Gender"])

# Plot 1: Speed of Impact vs Survival
plt.figure(figsize=(10, 6))
sns.boxplot(x="Survived", y="Speed_of_Impact", data=df_clean)
plt.title("Speed of Impact vs Survival")
plt.xlabel("Survived (1 = Yes, 0 = No)")
plt.ylabel("Speed of Impact (km/h)")
plt.show()

# Plot 2: Helmet Usage vs Survival
plt.figure(figsize=(6, 4))
sns.countplot(x="Helmet_Used", hue="Survived", data=df)
plt.title("Helmet Usage and Survival")
plt.xlabel("Helmet Used")
plt.ylabel("Count")
plt.legend(title="Survived")
plt.show()

# Plot 3: Seatbelt Usage vs Survival
plt.figure(figsize=(6, 4))
sns.countplot(x="Seatbelt_Used", hue="Survived", data=df)
plt.title("Seatbelt Usage and Survival")
plt.xlabel("Seatbelt Used")
plt.ylabel("Count")
plt.legend(title="Survived")
plt.show()

# Plot 4: Age vs Survival
plt.figure(figsize=(10, 6))
sns.histplot(data=df, x="Age", hue="Survived", multiple="stack", bins=15)
plt.title("Age Distribution by Survival")
plt.xlabel("Age")
plt.ylabel("Count")
plt.show()

# Plot 5: Gender vs Survival
plt.figure(figsize=(6, 4))
sns.countplot(x="Gender", hue="Survived", data=df_clean)
plt.title("Gender and Survival")
plt.xlabel("Gender")
plt.ylabel("Count")
plt.legend(title="Survived")
plt.show()
